/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
  import java.util.Scanner;


/**
 *
 * @author RC_Student_lab
 */

public class AccountValidationStrict {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String username;
        String password;
        String cellNumber;

        boolean isUsernameValid = false;
        boolean isPasswordValid = false;
        boolean isCellValid = false;

        // ✅ Username validation
        do {
            System.out.print("Enter Username (must contain _ and be max 5 characters): ");
            username = scanner.nextLine();

            isUsernameValid = username.contains("_") && username.length() <= 5;

            if (isUsernameValid) {
                System.out.println("Username successfully captured.");
            } else {
                System.out.println("Username is not correctly formatted.");
            }

        } while (!isUsernameValid);

        // ✅ Password validation
        do {
            System.out.print("Enter Password: ");
            password = scanner.nextLine();

            boolean hasLength = password.length() >= 8;
            boolean hasUpper = password.matches(".*[A-Z].*");
            boolean hasNumber = password.matches(".*[0-9].*");
            boolean hasSpecial = password.matches(".*[!@#$%^&*(),.?\":{}|<>].*");

            isPasswordValid = hasLength && hasUpper && hasNumber && hasSpecial;

            if (isPasswordValid) {
                System.out.println("Password successfully captured.");
            } else {
                System.out.println("Password is not correctly formatted.");
            }

        } while (!isPasswordValid);

        // ✅ Cellphone number validation (starts with 0 and 10 digits)
        do {
            System.out.print("Enter Cell Number (must start with 0 and be 10 digits): ");
            cellNumber = scanner.nextLine();

            isCellValid = cellNumber.startsWith("0") && cellNumber.length() == 10 && cellNumber.matches("[0-9]+");

            if (isCellValid) {
                System.out.println("Cellphone number successfully added.");
            } else {
                System.out.println("Cellphone number incorrectly formatted or does not contain international code.");
            }

        } while (!isCellValid);

        // ✅ Final message
        System.out.println("\nAccount created successfully!");
        System.out.println("Username: " + username);
        System.out.println("Cell Number: " + cellNumber); 
        
         // 🔐 Login section
        System.out.println("\n=== Login ===");

        System.out.print("Enter Username: ");
        String loginUsername = scanner.nextLine();

        System.out.print("Enter Password: ");
        String loginPassword = scanner.nextLine();

        if (loginUsername.equals(username) && loginPassword.equals(password)) {
            System.out.println(" Welcome, it is great to see you again.");
        } else {
            System.out.println("Username or password incorrect; plase try agin.");
        }

        scanner.close();
    }
}

        



